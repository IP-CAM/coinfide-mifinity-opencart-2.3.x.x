<?php
// Text
$_['text_title'] = 'MiFinity Payments';